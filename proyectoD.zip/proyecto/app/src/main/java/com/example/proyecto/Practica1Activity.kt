package com.example.proyecto

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Practica1Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_practica1) // Vincula el archivo XML
    }
}
