package com.example.proyecto
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnHolaMundo: Button = findViewById(R.id.btnHolaMundo)
        val btnContador1: Button = findViewById(R.id.btnContador1)
        val btnContador2: Button = findViewById(R.id.btnContador2)
        val btnContador3: Button = findViewById(R.id.btnContador3)
        val btnSQLite1: Button = findViewById(R.id.btnSQLite1)
        val btnSQLite2: Button = findViewById(R.id.btnSQLite2)

        btnHolaMundo.setOnClickListener {
            val intent = Intent(this, Practica1Activity::class.java)
            startActivity(intent)
        }


        btnContador1.setOnClickListener {
            val intent = Intent(this, Practica2Activity::class.java)
            startActivity(intent)
        }


        btnContador2.setOnClickListener {
            val intent = Intent(this, Practica3Activity::class.java)
            startActivity(intent)
        }


        btnContador3.setOnClickListener {
            val intent = Intent(this, Practica4Activity::class.java)
            startActivity(intent)
        }


        btnSQLite1.setOnClickListener {
            val intent = Intent(this, Practica5Activity::class.java)
            startActivity(intent)
        }

        btnSQLite2.setOnClickListener {
            val intent = Intent(this, Practica6Activity::class.java)
            startActivity(intent)
        }

    }
}
