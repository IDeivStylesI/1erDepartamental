package com.example.proyecto

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class Practica5Activity : AppCompatActivity() {

    private lateinit var dbHelper: DBHelper
    private lateinit var editTextName: EditText
    private lateinit var editTextAge: EditText
    private lateinit var buttonAdd: Button
    private lateinit var listViewNames: ListView
    private lateinit var namesAdapter: ArrayAdapter<String>
    private var namesList = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_practica5)

        // Inicializa vistas y DBHelper
        dbHelper = DBHelper(this)
        editTextName = findViewById(R.id.editTextName)
        editTextAge = findViewById(R.id.editTextAge)
        buttonAdd = findViewById(R.id.buttonAdd)
        listViewNames = findViewById(R.id.listViewNames)

        // Configura el adaptador para el ListView
        namesAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, namesList)
        listViewNames.adapter = namesAdapter

        // Carga los datos existentes
        loadNamesAndAges()

        // Evento para añadir nombres y edades
        buttonAdd.setOnClickListener {
            val name = editTextName.text.toString()
            val ageText = editTextAge.text.toString()

            if (name.isNotEmpty() && ageText.isNotEmpty()) {
                val age = ageText.toIntOrNull()
                if (age != null) {
                    val success = dbHelper.insertNameAndAge(name, age)
                    if (success) {
                        Toast.makeText(this, "Data added successfully!", Toast.LENGTH_SHORT).show()
                        editTextName.text.clear()
                        editTextAge.text.clear()
                        loadNamesAndAges()
                    } else {
                        Toast.makeText(this, "Failed to add data", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(this, "Please enter a valid age", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun loadNamesAndAges() {
        namesList.clear()
        namesList.addAll(dbHelper.getAllNamesAndAges())
        namesAdapter.notifyDataSetChanged()
    }
}
