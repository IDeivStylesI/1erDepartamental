package com.example.proyecto

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class Practica2Activity : AppCompatActivity() {

    private var contador: Int = 0
    private lateinit var textViewCount: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_practica2)

        textViewCount = findViewById(R.id.textViewCount)
        val buttonIncrement: Button = findViewById(R.id.buttonIncrement)

        buttonIncrement.setOnClickListener {
            incrementarContador()
        }
    }

    private fun incrementarContador() {
        contador++
        textViewCount.text = contador.toString()
    }
}
