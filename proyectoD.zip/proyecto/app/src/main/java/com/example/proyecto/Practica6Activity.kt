package com.example.proyecto

import android.app.AlertDialog
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class Practica6Activity : AppCompatActivity() {

    private lateinit var dbHelper: DBHelper2
    private lateinit var timerTextView: TextView
    private lateinit var scoreTextView: TextView
    private lateinit var incrementButton: Button
    private lateinit var addScoreButton: Button
    private lateinit var historyListView: ListView
    private lateinit var historyAdapter: ArrayAdapter<String>
    private var historyList = mutableListOf<String>()
    private var clickCount = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_practica6)

        // Inicializar vistas
        dbHelper = DBHelper2(this)
        timerTextView = findViewById(R.id.timerTextView)
        scoreTextView = findViewById(R.id.scoreTextView)
        incrementButton = findViewById(R.id.incrementButton)
        addScoreButton = findViewById(R.id.addScoreButton)
        historyListView = findViewById(R.id.historyListView)

        // Configurar el adaptador del ListView
        historyAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, historyList)
        historyListView.adapter = historyAdapter

        // Cargar el historial almacenado
        loadHistory()

        // Configurar botón de incremento
        incrementButton.setOnClickListener {
            clickCount++
            scoreTextView.text = "Marcador: $clickCount"
        }

        // Configurar botón de guardar
        addScoreButton.setOnClickListener {
            saveScore()
        }

        // Iniciar temporizador de 10 segundos
        startTimer()
    }

    private fun startTimer() {
        clickCount = 0
        scoreTextView.text = "Marcador: 0"
        incrementButton.isEnabled = true
        addScoreButton.isEnabled = false

        val timer = object : CountDownTimer(10000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                timerTextView.text = "Tiempo: ${millisUntilFinished / 1000} segundos"
            }

            override fun onFinish() {
                timerTextView.text = "¡Tiempo agotado!"
                incrementButton.isEnabled = false
                addScoreButton.isEnabled = true

                // Mostrar AlertDialog con el total de clics
                showAlert(clickCount)
            }
        }
        timer.start()
    }

    private fun showAlert(clicks: Int) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Resultado")
        builder.setMessage("Total de clics: $clicks")
        builder.setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
        builder.show()
    }

    private fun saveScore() {
        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        val success = dbHelper.insertScore(clickCount, timestamp)
        if (success) {
            Toast.makeText(this, "Score guardado: $clickCount", Toast.LENGTH_SHORT).show()
            loadHistory()
        } else {
            Toast.makeText(this, "Error al guardar el score", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadHistory() {
        historyList.clear()
        val scores = dbHelper.getAllScores()
        scores.forEach { score ->
            historyList.add("Score: ${score.first}, Fecha: ${score.second}")
        }
        historyAdapter.notifyDataSetChanged()
    }
}
