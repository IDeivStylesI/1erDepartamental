package com.example.proyecto

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class Practica3Activity : AppCompatActivity() {

    private var score = 0 // Contador de clics
    private lateinit var clickButton: Button
    private lateinit var scoreTextView: TextView
    private lateinit var timerTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_practica3)

        // Vincular elementos del diseño
        timerTextView = findViewById(R.id.timerTextView)
        scoreTextView = findViewById(R.id.scoreTextView)
        clickButton = findViewById(R.id.clickButton)

        // Temporizador de 10 segundos
        val handler = Handler(Looper.getMainLooper())
        handler.postDelayed({
            clickButton.isEnabled = false // Deshabilita el botón
            mostrarDialogoFinal() // Muestra el AlertDialog con el total de clics
        }, 10000) // 10 segundos

        // Actualización del temporizador en pantalla
        val startTime = System.currentTimeMillis()
        val timerHandler = Handler(Looper.getMainLooper())
        val timerRunnable = object : Runnable {
            override fun run() {
                val elapsedSeconds = (System.currentTimeMillis() - startTime) / 1000
                val remainingTime = 10 - elapsedSeconds
                if (remainingTime >= 0) {
                    timerTextView.text = "Tiempo: $remainingTime segundos"
                    timerHandler.postDelayed(this, 1000)
                }
            }
        }
        timerHandler.post(timerRunnable)

        // Incrementar contador al hacer clic
        clickButton.setOnClickListener {
            score++
            scoreTextView.text = "Marcador: $score"
        }
    }

    private fun mostrarDialogoFinal() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Tiempo Finalizado")
        builder.setMessage("Número total de clics: $score")
        builder.setPositiveButton("Aceptar") { dialog, _ ->
            dialog.dismiss()
        }
        builder.create().show()
    }
}
