package com.example.proyecto

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper2(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "ScoreHistory.db"
        private const val DATABASE_VERSION = 1
        private const val TABLE_NAME = "scores"
        private const val COLUMN_ID = "id"
        private const val COLUMN_SCORE = "score"
        private const val COLUMN_TIMESTAMP = "timestamp"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTable = "CREATE TABLE $TABLE_NAME ($COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT, $COLUMN_SCORE INTEGER, $COLUMN_TIMESTAMP TEXT)"
        db.execSQL(createTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    fun insertScore(score: Int, timestamp: String): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_SCORE, score)
            put(COLUMN_TIMESTAMP, timestamp)
        }
        val result = db.insert(TABLE_NAME, null, values)
        db.close()
        return result != -1L
    }

    fun getAllScores(): List<Pair<Int, String>> {
        val db = readableDatabase
        val cursor = db.query(TABLE_NAME, null, null, null, null, null, null)
        val scores = mutableListOf<Pair<Int, String>>()

        if (cursor.moveToFirst()) {
            do {
                val score = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_SCORE))
                val timestamp = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TIMESTAMP))
                scores.add(Pair(score, timestamp))
            } while (cursor.moveToNext())
        }

        cursor.close()
        db.close()
        return scores
    }
}
