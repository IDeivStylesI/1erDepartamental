package com.example.proyecto

import android.os.Bundle
import android.os.CountDownTimer
import android.os.Environment
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.File

class Practica4Activity : AppCompatActivity() {

    private var score = 0 // Contador de clics
    private lateinit var clickButton: Button
    private lateinit var btnSaveScore: Button
    private lateinit var scoreTextView: TextView
    private lateinit var timerTextView: TextView
    private lateinit var historialTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_practica4)

        // Vincular elementos del diseño
        timerTextView = findViewById(R.id.timerTextView)
        scoreTextView = findViewById(R.id.scoreTextView)
        clickButton = findViewById(R.id.clickButton)
        btnSaveScore = findViewById(R.id.btnSaveScore)
        historialTextView = findViewById(R.id.historialTextView)

        // Configurar el temporizador
        val timer = object : CountDownTimer(10000, 1000) { // Temporizador de 10 segundos
            override fun onTick(millisUntilFinished: Long) {
                timerTextView.text = "Tiempo: ${millisUntilFinished / 1000} segundos"
            }

            override fun onFinish() {
                timerTextView.text = "¡Tiempo agotado!"
                clickButton.isEnabled = false
            }
        }

        // Incrementar contador al hacer clic
        clickButton.setOnClickListener {
            score++
            scoreTextView.text = "Marcador: $score"
        }

        // Guardar marcador en historial y actualizar pantalla
        btnSaveScore.setOnClickListener {
            guardarEnHistorial("Score: $score")
            guardarScoreEnArchivo("Score: $score") // También guarda en el archivo score.txt
            cargarHistorialEnPantalla() // Actualiza el historial
        }

        // Iniciar el temporizador
        timer.start()

        // Cargar el historial existente al iniciar
        cargarHistorialEnPantalla()
    }

    private fun guardarEnHistorial(resultado: String) {
        val file = File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "historial.txt")
        try {
            file.appendText("$resultado\n") // Agrega al archivo historial.txt
            Toast.makeText(this, "Historial actualizado correctamente.", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Error al guardar el historial: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun cargarHistorialEnPantalla() {
        val file = File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "historial.txt")
        if (file.exists()) {
            val contenido = file.readText()
            historialTextView.text = "Historial:\n$contenido"
        } else {
            historialTextView.text = "Historial:\n(Sin registros)"
        }
    }

    private fun guardarScoreEnArchivo(resultado: String) {
        val file = File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "score.txt")
        try {
            file.writeText(resultado) // Sobrescribe el archivo con el marcador actual
            Toast.makeText(this, "Score guardado en: ${file.absolutePath}", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Error al guardar el score: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

}
